import requests
import random
import string
import time
import re

BASE_URL = "https://api.mail.tm"

def random_name(length=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def get_domains():
    r = requests.get(f"{BASE_URL}/domains")
    return r.json()['hydra:member'][0]['domain']

def register_account(email, password):
    payload = {"address": email, "password": password}
    r = requests.post(f"{BASE_URL}/accounts", json=payload)
    return r.status_code in [201, 422]

def get_token(email, password):
    payload = {"address": email, "password": password}
    r = requests.post(f"{BASE_URL}/token", json=payload)
    return r.json()['token']

def get_messages(token):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"{BASE_URL}/messages", headers=headers)
    return r.json().get('hydra:member', [])

def read_message(token, message_id):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"{BASE_URL}/messages/{message_id}", headers=headers)
    return r.json()

def generate_temp_mail_account():
    username = random_name()
    password = random_name(12)
    domain = get_domains()
    email = f"{username}@{domain}"
    register_account(email, password)
    token = get_token(email, password)
    return email, password, token

def wait_for_emails(token, expected_count=2, timeout=90, interval=5):
    attempts = timeout // interval
    for _ in range(attempts):
        inbox = get_messages(token)
        if len(inbox) >= expected_count:
            return inbox[:expected_count]
        time.sleep(interval)
    return get_messages(token)

def extract_otp(text):
    match = re.search(r'\b\d{6}\b', text)
    return match.group(0) if match else None

def get_otp_from_first_email(token):
    emails = wait_for_emails(token, expected_count=1)

    if not emails:
        print("❌ No email received.")
        return None

    msg = read_message(token, emails[0]['id'])
    otp = extract_otp(msg['text'])

    if otp:
        print("🔐 Extracted OTP:", otp)
    else:
        print("❌ OTP not found in email.")

    return otp

def print_second_email(token, emails):
    if len(emails) < 2:
        print("❌ Less than 2 emails available.")
        return

    msg = read_message(token, emails[1]['id'])
    print("\n📧 Full Email Content (2nd Email):\n")
    print(msg['text'])

def _clean_link(link):
    """Decode HTML entities and clean up a URL."""
    link = link.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&#43;', '+')
    link = link.replace('%2524', '%24').replace('%2B', '+')
    # Strip trailing punctuation that got captured
    link = re.sub(r'[)\]>.,;"\'\s]+$', '', link)
    return link

def _extract_from_html(html_text):
    """Pull href URLs out of anchor tags in HTML email bodies."""
    hrefs = re.findall(r'href=["\']([^"\']+)["\']', html_text, re.IGNORECASE)
    for href in hrefs:
        href = _clean_link(href)
        if 'account.live.com/password/reset' in href or \
           'account.microsoft.com/password/reset' in href or \
           'passwordreset.microsoftonline.com' in href or \
           'cxt=Acsr' in href or 'cxt=acsr' in href.lower():
            return href
    return None

def extract_specific_link(text):
    if not text:
        return None

    # Priority 0: HTML anchor href extraction (handles HTML emails)
    if '<a ' in text or '<A ' in text:
        link = _extract_from_html(text)
        if link:
            print(f"✅ Reset link found via HTML href extraction.")
            return link
        # Strip all HTML tags for text-based search below
        text_plain = re.sub(r'<[^>]+>', ' ', text)
        text_plain = text_plain.replace('&amp;', '&').replace('&nbsp;', ' ')
    else:
        text_plain = text

    # Priority 1: Microsoft ACSR email exact pattern — ends with &cxt=Acsr
    # Handles the format: https://account.live.com/password/reset?ft=<long_token>&cxt=Acsr
    # The token can contain letters, digits, -, *, !, %, =, and other URL-safe chars
    acsr_pattern = r'https://account\.live\.com/password/reset\?ft=[^\s\r\n<>"\']*(?:&(?:amp;)?cxt=Acsr|%26cxt%3DAcsr)'
    match = re.search(acsr_pattern, text_plain, re.IGNORECASE)
    if match:
        return _clean_link(match.group(0))

    # Priority 2: Look for "Click this link to reset your password:" — grab next non-empty line
    lines = text_plain.splitlines()
    for i, line in enumerate(lines):
        if "Click this link to reset your password:" in line or \
           "click this link to reset" in line.lower() or \
           ("reset" in line.lower() and "password" in line.lower()):
            # Collect the next several lines and join — link may be wrapped across lines
            candidate = ""
            for j in range(i + 1, min(i + 15, len(lines))):
                stripped = lines[j].strip()
                if not stripped:
                    if candidate:
                        break
                    continue
                if stripped.startswith("http"):
                    candidate = stripped
                elif candidate:
                    # Continue collecting if the line looks like a URL continuation
                    if re.match(r'^[A-Za-z0-9%_\-.*!+=/&?]+$', stripped):
                        candidate += stripped
                    else:
                        break
            if candidate.startswith("http"):
                return _clean_link(candidate)

    # Priority 3: Regex search for known Microsoft reset URL patterns (full char set including * ! ~)
    url_chars = r'[^\s\r\n<>"\'\\]+'
    patterns = [
        rf'https://account\.live\.com/password/reset{url_chars}',
        rf'https://account\.microsoft\.com/password/reset{url_chars}',
        rf'https://passwordreset\.microsoftonline\.com{url_chars}',
        rf'https://account\.live\.com/acsr{url_chars}',
    ]
    for pattern in patterns:
        match = re.search(pattern, text_plain, re.IGNORECASE)
        if match:
            return _clean_link(match.group(0))

    # Priority 4: Any https link containing reset/password/recover keywords
    all_links = re.findall(r'https://[^\s\r\n<>"\'\\]+', text_plain)
    for link in all_links:
        if any(kw in link.lower() for kw in ['reset', 'password', 'recover', 'acsr']):
            return _clean_link(link)

    print("⚠️ Could not find reset link with known patterns, dumping all found URLs:")
    for link in all_links:
        print(f"   - {link}")

    return None
