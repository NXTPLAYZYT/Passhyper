from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from tempmail import get_otp_from_first_email, wait_for_emails, read_message, extract_specific_link, get_messages
from datetime import datetime
from automation.captcha import download_captcha
import os
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_month_name(date_str):
    try:
        date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        month_name = date_obj.strftime("%B")
        day = str(date_obj.day)
        year = str(date_obj.year)
        return month_name, day, year
    except ValueError:
        return "May", "5", "1989"


def continue_acsr_flow(driver, account_info, token, captcha_text, user_id, progress_fn=None):
    """
    progress_fn(msg: str) — called for every step so the bot can relay it to Discord live.
    Falls back to print() if not provided.
    """
    wait = WebDriverWait(driver, 20)

    def log(msg):
        print(msg)
        if progress_fn:
            try:
                progress_fn(msg)
            except Exception:
                pass

    try:
        # ── CAPTCHA ──────────────────────────────────────────────────────────
        try:
            captcha_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[contains(@id, "SolutionElement")]'))
            )
            captcha_input.clear()
            captcha_input.send_keys(captcha_text)
            captcha_input.send_keys(Keys.RETURN)
            log("📨 CAPTCHA submitted — waiting for OTP field...")

            code_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "iOttText"))
            )
            log("✅ CAPTCHA accepted!")

        except Exception:
            log("❌ CAPTCHA incorrect — fetching new image...")
            try:
                captcha_image = download_captcha(driver)
                log("🧩 New CAPTCHA ready.")
                with open(os.path.join(BASE_DIR, f"captcha_retry_{user_id}.png"), "wb") as f:
                    f.write(captcha_image.read())
                return "CAPTCHA_RETRY_NEEDED"
            except Exception as e:
                log(f"❌ Could not download new CAPTCHA: {e}")
                return "CAPTCHA_DOWNLOAD_FAILED"

        # ── OTP ───────────────────────────────────────────────────────────────
        log("⌛ Waiting for OTP from temp email...")
        otp = get_otp_from_first_email(token)
        if not otp:
            log("❌ OTP not received from temp mail.")
            return "❌ OTP not received."

        log(f"📥 OTP received: `{otp}`")

        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(otp)
        code_input.send_keys(Keys.RETURN)
        log("🔐 OTP submitted successfully.")
        time.sleep(2)

        # ── NAME ──────────────────────────────────────────────────────────────
        log(f"🧾 Filling name: **{account_info['name']}**")
        first, last = account_info['name'].split(maxsplit=1) if ' ' in account_info['name'] else (account_info['name'], "Last")
        wait.until(EC.presence_of_element_located((By.ID, "FirstNameInput"))).send_keys(first)
        wait.until(EC.presence_of_element_located((By.ID, "LastNameInput"))).send_keys(last)

        # ── DOB ───────────────────────────────────────────────────────────────
        month, day, year = get_month_name(account_info['dob'])
        if not all([month, day, year]):
            raise ValueError("❌ Invalid or missing DOB, aborting ACSR form.")

        Select(WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_dayInput"))
        )).select_by_visible_text(day)

        month_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_monthInput"))
        )
        Select(month_element).select_by_visible_text(month)

        Select(WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_yearInput"))
        )).select_by_visible_text(year)

        log(f"📆 DOB filled: **{month} {day}, {year}**")

        # ── REGION ────────────────────────────────────────────────────────────
        wait.until(EC.presence_of_element_located((By.ID, "CountryInput"))).send_keys(account_info['region'])
        log(f"🌍 Region filled: **{account_info['region']}**")
        time.sleep(1)

        # ── SUBMIT NAME PAGE ──────────────────────────────────────────────────
        driver.find_element(By.ID, "FirstNameInput").send_keys(Keys.RETURN)
        time.sleep(1)

        # ── OLD PASSWORD ──────────────────────────────────────────────────────
        log("🔑 Entering old password...")
        previous_pass_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'))
        )
        previous_pass_input.clear()
        previous_pass_input.send_keys(account_info["password"])
        log("✅ Old password entered.")
        time.sleep(2)

        # ── SKYPE + XBOX CHECKBOXES ───────────────────────────────────────────
        skype_checkbox = driver.find_element(By.ID, "ProductOptionSkype")
        if not skype_checkbox.is_selected():
            skype_checkbox.click()
            log("☑️ Skype option selected.")

        xbox_checkbox = driver.find_element(By.ID, "ProductOptionXbox")
        if not xbox_checkbox.is_selected():
            xbox_checkbox.click()
            log("🎮 Xbox option selected.")

        # ── SKYPE INFO ────────────────────────────────────────────────────────
        previous_pass_input.send_keys(Keys.RETURN)
        skype_name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "SkypeNameInput"))
        )
        skype_name_input.clear()
        skype_name_input.send_keys(account_info["skype_id"])

        skype_email_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput"))
        )
        skype_email_input.clear()
        skype_email_input.send_keys(account_info["skype_email"])
        log(f"🔑 Skype info filled: `{account_info['skype_id']}`")
        time.sleep(2)
        skype_email_input.send_keys(Keys.RETURN)

        # ── XBOX ONE ──────────────────────────────────────────────────────────
        log("🎮 Selecting Xbox One...")
        xbox_radio = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "XboxOneOption"))
        )
        if not xbox_radio.is_selected():
            xbox_radio.click()
        xbox_radio.send_keys(Keys.ENTER)
        log("✅ Xbox One selected.")
        time.sleep(2)

        # ── GAMERTAG ──────────────────────────────────────────────────────────
        log(f"🎮 Entering Gamertag: `{account_info['gamertag']}`")
        xbox_name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "XboxGamertagInput"))
        )
        xbox_name_input.clear()
        xbox_name_input.send_keys(account_info["gamertag"])
        xbox_name_input.send_keys(Keys.RETURN)
        log("✅ Gamertag submitted.")

        # ── WAIT FOR RESET EMAIL ──────────────────────────────────────────────
        # Subject keywords that identify the SUCCESS email (contains the reset link)
        SUCCESS_SUBJECTS = [
            "your account is verified",
            "reset your password",
            "verified and now you just need",
        ]
        # Subject keywords that identify a REJECTION email — skip entirely
        REJECT_SUBJECTS = [
            "your account recovery request",
            "information you provided was not sufficient",
            "donotEdit",
        ]

        def is_success_email(subject: str) -> bool:
            sl = subject.lower()
            return any(k in sl for k in SUCCESS_SUBJECTS)

        def is_rejection_email(subject: str) -> bool:
            sl = subject.lower()
            return any(k.lower() in sl for k in REJECT_SUBJECTS)

        log("📬 Waiting for Microsoft reset email (up to 3 min)...")
        log("✅ Want: \"Your account is verified and now you just need to reset your password\"")
        log("❌ Skip: \"Your account recovery request\" (rejection — info not sufficient)")

        resetlink = None
        rejected_count = 0

        for attempt in range(18):
            time.sleep(10)
            log(f"📨 Checking inbox... attempt **{attempt + 1}/18**")

            try:
                emails = get_messages(token)
            except Exception as e:
                log(f"⚠️ Could not fetch inbox: {e}")
                continue

            if not emails:
                log("📭 Inbox empty — waiting...")
                continue

            log(f"📬 Found **{len(emails)}** email(s) in inbox")

            for idx, email_meta in enumerate(emails):
                subject = email_meta.get('subject', 'No subject')
                log(f"📧 Checking email {idx + 1}: **{subject}**")

                # ── Rejection email — report and skip ──────────────────────
                if is_rejection_email(subject):
                    rejected_count += 1
                    log(f"   ❌ REJECTED by Microsoft — info not sufficient (rejection #{rejected_count})")
                    log("   ↳ Skipping this email, waiting for verified success email...")
                    continue

                # ── Not clearly a success email — note it and skip ─────────
                if not is_success_email(subject):
                    log(f"   ⚠️ Unknown email subject — skipping (not the verified email)")
                    continue

                # ── Success email — extract link ───────────────────────────
                log(f"   ✅ This looks like the verified success email! Extracting reset link...")
                try:
                    msg = read_message(token, email_meta['id'])
                    email_text = msg.get('text', '') or ''
                    email_html = msg.get('html', '') or ''
                    # Prefer HTML — it contains properly encoded hrefs
                    if len(email_text.strip()) < 100 and email_html:
                        email_text = email_html
                    elif email_html and 'account.live.com' in email_html and 'account.live.com' not in email_text:
                        email_text = email_html
                    link = extract_specific_link(email_text)
                    if link:
                        resetlink = link
                        log(f"   🔗 Reset link extracted successfully!")
                        break
                    else:
                        log(f"   ⚠️ Could not extract link from verified email — will retry.")
                except Exception as e:
                    log(f"   ⚠️ Error reading email {idx + 1}: {e}")
                    continue

            if resetlink:
                break

            if rejected_count > 0:
                log(f"⏳ Got {rejected_count} rejection(s) so far — still waiting for verified email...")

        try:
            driver.quit()
        except Exception:
            pass

        if resetlink:
            log("🔗 Reset link extracted — starting password reset...")
            return resetlink
        else:
            log("❌ Reset link not found after all attempts.")
            return None

    except Exception as e:
        log(f"❌ Error during ACSR flow: {e}")
        return None
